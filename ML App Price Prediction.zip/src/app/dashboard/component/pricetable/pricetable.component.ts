import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pricetable',
  templateUrl: './pricetable.component.html',
  styleUrls: ['./pricetable.component.css']
})
export class PriceTableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
