import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  @ViewChild('username') username;
  @ViewChild('password') password;

  
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  static flag = "../../assets/img/LOGO-main-light@2x.png";
  constructor(private router: Router, private _snackBar: MatSnackBar) { }

  ngOnInit() {
  }

  loginBtn() {
    if (this.username.nativeElement.value == 'zennaro' && this.password.nativeElement.value == 'server123') {
      LoginComponent.flag = "../../assets/img/main_logo.237c4126.png";
      this.router.navigate(['/dashboard']);
    }
    if (this.username.nativeElement.value == 'infobeans' && this.password.nativeElement.value == 'server123') {
      LoginComponent.flag = "../../assets/img/LOGO-main-light@2x.png";
      this.router.navigate(['/dashboard']);
    }
  }
  ShowError() {
    this._snackBar.open('Invalid Credentials!', 'Close', {
      duration: 2000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
    });
  }
}
