import { Component, OnInit, ViewChild } from '@angular/core';
import { FileUtil } from './file.util';
import { Constants } from './test.constants';
import { Router } from "@angular/router";
import { LoaderService } from 'app/shared/loader/loader.service';
import { DataAnalysisService } from 'app/core/services/data-analysis/data-analysis.service'
import { DataExportService } from 'app/core/services/dataExport.service';
import { Subscription } from 'rxjs';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';

@Component({
  selector: 'app-data-analysis',
  templateUrl: './data-analysis.component.html',
  styleUrls: ['./data-analysis.component.css']
})

export class DataAnalysisComponent implements OnInit {

  @ViewChild('csvReader') csvReader: any;
  @ViewChild('fileImportInput') fileImportInput: any;


  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  //local variables
  csvRecords: any[] = [];
  csvRecordsPredicted: any[] = [];
  JSONObj: any;
  HeaderObj:any[]=[];
  isPredicted: boolean = false;
  result = [];
  Score: any = '';
  subscription: Subscription
  constructor(
    private _router: Router,
    private _fileUtil: FileUtil,
    private loaderService: LoaderService,
    private dataAnalysisService: DataAnalysisService,
    private dataExportService: DataExportService,
    private _snackBar: MatSnackBar
  ) { }

  ngOnInit() {

  }

  csvJSON(csv) {
    //var lines = csv.split("\n");
    var lines = csv.split(/\r\n|\n/);
    var headers = lines[0].split(",");

    for (var i = 1; i < lines.length; i++) {        
      var obj = {};
      var currentline = lines[i].split(",");                     
                                                                              
      for (var j = 0; j < headers.length; j++) {
        obj[headers[j]] = currentline[j];                    
      }
      this.result.push(obj);
    }
    this.result.pop();
    const object = this.result;
    return JSON.stringify(object);
  }
     
  // METHOD CALLED WHEN CSV FILE IS IMPORTED
  fileChangeListener($event): void {
    var text = [];
    var target = $event.target || $event.srcElement;
    var files = target.files;

    if (Constants.validateHeaderAndRecordLengthFlag) {
      if (!this._fileUtil.isCSVFile(files[0])) {
        this.loaderService.hide();
        alert("Please import valid .csv file.");
        this.fileReset();
      }
    }

    var input = $event.target;
    var reader = new FileReader();
    reader.readAsText(input.files[0]);

    reader.onload = (data) => {
      let csvData = reader.result;
      this.JSONObj = this.csvJSON(csvData);
      let csvRecordsArray = (<any>csvData).split(/\r\n|\n/);

      var headerLength = -1;
      if (Constants.isHeaderPresentFlag) {
        let headersRow = this._fileUtil.getHeaderArray(csvRecordsArray, Constants.tokenDelimeter);
        headersRow.forEach(item => {    
          item = item.replace('_',' ');
          item = item.replace('_',' ');
          item = item.charAt(0).toUpperCase() + item.substring(1);
          this.HeaderObj.push(item)
        });
        headerLength = headersRow.length;
      }

      this.csvRecords = this._fileUtil.getDataRecordsArrayFromCSVFile(csvRecordsArray,
        headerLength, Constants.validateHeaderAndRecordLengthFlag, Constants.tokenDelimeter);
        this.csvRecords  = this.csvRecords.slice(1);
      if (this.csvRecords == null) {
        this.loaderService.hide();
        //If control reached here it means csv file contains error, reset file.
        this.fileReset();
      }
    }
    reader.onerror = function () {
      alert('Unable to read ' + input.files[0]);
    };
  };

  predict() {
    this.loaderService.show();
    this.dataAnalysisService.Predict(this.JSONObj).subscribe(res => {
      var predictedJson: any[] = res;
      if(res[0].accuracy !== undefined){
        this.Score = parseFloat(res[0].accuracy).toFixed(2);
        this.Score = this.Score*100;
      }
      let isKeyPresent:boolean  =  this.HeaderObj.includes("Predicted price")
      if(!isKeyPresent){
        this.HeaderObj.unshift("Predicted price");
      }
      this.csvRecords.pop();
      for (var j = 1; j < this.csvRecords.length+1; j++) {
        this.csvRecords[j-1].unshift(predictedJson[j - 1].predicted_value ? parseFloat(predictedJson[j - 1].predicted_value).toFixed(2) : 0);
      }
      this.isPredicted = true;
      this.csvRecordsPredicted = this.csvRecords;
      this.loaderService.hide();
      if(this.Score !==''){
        this._snackBar.open('Accuracy is  ' + this.Score +' %', 'Close', {
          duration: 10000,
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
        });
      }
    });
  }
      
  downloadFile() {
    if (this.csvRecords.length > 0)
      this.dataExportService.downloadFileGeneric(this.csvRecordsPredicted);
  }

  fileReset() {
    this.loaderService.show();
    this.fileImportInput.nativeElement.value = "";
    this.csvRecords = [];
    this.result = [];
    this.HeaderObj = [];
    this.Score = '';
    this.csvRecordsPredicted = [];
    if (this.isPredicted) this.isPredicted = false;
    this.loaderService.hide();
  }
}
