import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})

export class DataAnalysisService {
  // Base url Azure
  baseurl = 'https://ibpythonmlapp.azurewebsites.net';

  constructor(private http: HttpClient) { }

  // Http Headers
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }
  // POST
  Predict(data: any): Observable<any> {
    return this.http.post<any>(this.baseurl + '/predict_api', data, this.httpOptions)
      .pipe(
        catchError(this.errorHandle)
      )
  }

  // GET
  GetByID(id): Observable<any> {
    return this.http.get<any>(this.baseurl + '/xyz/' + id)
      .pipe(
        retry(1),
        catchError(this.errorHandle)
      )
  }

  // GET
  Get(): Observable<any> {
    return this.http.get<any>(this.baseurl + '/xyz/')
      .pipe(
        retry(1),
        catchError(this.errorHandle)
      )
  }

  // PUT
  Update(id, data): Observable<any> {
    return this.http.put<any>(this.baseurl + '/xyz/' + id, JSON.stringify(data), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandle)
      )
  }

  // DELETE
  Delete(id) {
    return this.http.delete<any>(this.baseurl + '/xyz/' + id, this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandle)
      )
  }

  // Error handling
  errorHandle(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(errorMessage);
  }
}
